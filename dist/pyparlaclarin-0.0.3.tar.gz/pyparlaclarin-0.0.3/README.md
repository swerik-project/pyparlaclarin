# Pyparlaclarin

This module includes functionality for reading, creating, and modifying Parla-Clarin XML files.

Install by running

```bash
pip install pyparlaclarin
```
